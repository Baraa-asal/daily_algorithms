package com.riyadbusttami.median;


import java.util.*;
public class Test {

	public static void main(String[] args) {
		Median median=new Median();
		ArrayList<Integer> arr1=new ArrayList<Integer>();
		arr1.add(1);
		arr1.add(5);
		arr1.add(9);
		ArrayList<Integer> arr2=new ArrayList<Integer>();
		arr2.add(1);
		arr2.add(2);
		arr2.add(3);
		arr2.add(4);
		arr2.add(5);
		ArrayList<ArrayList<Integer>> arrOfArr=new ArrayList<ArrayList<Integer>>();
		arrOfArr.add(arr1);
		arrOfArr.add(arr2);
		System.out.println("FirstArray Median="+median.getMedian(arr1));
		System.out.println("Two Arrays median="+median.getArraysMedian(arrOfArr));
		

	}

}
