package com.riyadbusttami.median;

import java.util.*;
public class Median {
	public double getMedian(ArrayList<Integer> arr) {
		arr.sort(null);
		if(arr.size()%2==0) {
			
			return (arr.get(arr.size()/2)+arr.get((arr.size()/2)-1))/2.0;
		}
		else {
			return arr.get((arr.size()-1)/2);
		}
	}
	public double getArraysMedian(ArrayList<ArrayList<Integer>> arr) {
		ArrayList<Integer> newArr=new ArrayList<Integer>();
		for (ArrayList<Integer> array : arr) {
			newArr.addAll(array);
		}
		newArr.sort(null);
		return this.getMedian(newArr);
	}
}
